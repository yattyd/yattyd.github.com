/* compiling: tcc read.c -o read.exe */
#include <stdio.h>     
     
int readline(char *line, int siz)
{
	char *p;
	
	fgets(line, siz, stdin);
	for (p=line; *p; ++p) {
	        if (*p == '\r' || *p == '\n') {
			*p = '\0';
			break;		
		}
	}	
	return 0;
} 

int main(int argc, char **argv)
{
	char line[1024];
	readline(line, 1024);
	printf(line);
	return 0;
}
